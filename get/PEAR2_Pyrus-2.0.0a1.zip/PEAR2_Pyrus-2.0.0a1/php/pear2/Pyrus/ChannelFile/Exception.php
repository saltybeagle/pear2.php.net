<?php
namespace pear2\Pyrus\ChannelFile;
class Exception extends \pear2\Exception {}