<?php
class PEAR2_SimpleChannelServer_Categories_Exception extends \pear2\Exception {}